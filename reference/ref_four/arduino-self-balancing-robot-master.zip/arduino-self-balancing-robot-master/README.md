# Arduino Self-Balancing Robot

This project is seen on DIYHacking: https://diyhacking.com/build-arduino-self-balancing-robot

This repo includes the library needed to build the robot.

Credits to the original creator of these libraries: 
  MPU6050, 
  PID, 
  LMotorController
  
  
  
More [Microcontroller Tutorials] https://www.teachmemicro.com
