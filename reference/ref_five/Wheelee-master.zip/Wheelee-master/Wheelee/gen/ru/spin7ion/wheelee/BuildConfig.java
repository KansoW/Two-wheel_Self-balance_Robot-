/** Automatically generated file. DO NOT MODIFY */
package ru.spin7ion.wheelee;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}